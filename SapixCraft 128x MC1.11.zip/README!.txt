SapixCraft 
By Sapix

Managers for this pack
Sapix

This pack requires the very latest version of Optifine.

Website:
http://sapixmedia.com



Terms of Use:

DO NOT post this file as download on your own website! Always refer to <sapixmedia.com>.

You are certainly allowed to use this pack in youtube videos & streams, providing that a link to the website
& resourcepack used.

You�re are certainly NOT allowed to put this website or any SapixCraft download link behind adf.ly.

Private redistribution & private mix-packs are allowed.

Server texture packs are NOT allowed. This means you may not distribute the pack to members of your server using the resourcepack
downloader. But you can always contact me for this.

You may edit these textures for use in an adventure map, but credit and a link to the website and creator MUST be given.
The edited resourcepack must be within the download of the adventure map.

You are welcome to send your own alterations of any texture or any original texture/mods to SapixProductions@outlook.com 

Public mix-packs must have permission from the council & must link directly to the Sapixcraft website, with credit given.

Do not use any textures created for the continuation in your own resourcepack you intend to release, not even as place-holders.

You are not allowed to use this pack for any commercial purposes.

If you'd like to use any of this work for a remix or
as a base for your own pack be sure to read and
follow 'Terms of Use' above.


If you downloaded this texture pack from anywhere 
other than the SapixCraft website, please inform us
at: <mail@sapixmedia.com> You may not get a response,
but it provides me with valuable feedback to ensure
ower work isn't being illegally stolen for profit.

� 2018, SapixCraft <mail@sapixmedia.com >
